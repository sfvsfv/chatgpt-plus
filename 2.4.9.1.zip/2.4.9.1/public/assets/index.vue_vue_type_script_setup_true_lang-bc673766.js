import{aV as se,ac as t,aD as j,aA as b,aE as I,d as W,b as R,aW as re,aX as Y,aY as _e,aZ as $e,a_ as Be,a$ as Te,aG as Pe,aH as pe,b0 as Ye,aP as me,aL as De,b1 as Ze,aa as ce,b2 as ge,b3 as Je,b4 as Qe,b5 as et,b6 as Le,r as E,b7 as tt,b8 as rt,V as nt,z as Q,b9 as ot,aS as it,ba as at,bb as lt,bc as ve,aB as K,aC as st,aI as ct,aJ as M,aK as dt,bd as ut,be as ft,F as ie,bf as pt,bg as ye,P as Ie,aU as be,a5 as he,o as D,c as F,a as O,A as X,t as ee,u as g,s as gt,f as B,_ as A,C as ne,i as ze,v as q,w as J,q as ht,l as Ue,I as Fe,Y as mt,m as Oe,k as Ne,p as ae,e as vt,a3 as yt,ae as bt,n as xt,Q as wt,K as xe,bh as Ct,bi as kt}from"./index-9fb4c050.js";import{N as Rt}from"./Popconfirm-f7b33c6a.js";import{N as we}from"./NumberAnimation-03e81213.js";import{N as St}from"./LayoutSider-9f17b0cc.js";const _t=se("attach",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M3.25735931,8.70710678 L7.85355339,4.1109127 C8.82986412,3.13460197 10.4127766,3.13460197 11.3890873,4.1109127 C12.365398,5.08722343 12.365398,6.67013588 11.3890873,7.64644661 L6.08578644,12.9497475 C5.69526215,13.3402718 5.06209717,13.3402718 4.67157288,12.9497475 C4.28104858,12.5592232 4.28104858,11.9260582 4.67157288,11.5355339 L9.97487373,6.23223305 C10.1701359,6.0369709 10.1701359,5.72038841 9.97487373,5.52512627 C9.77961159,5.32986412 9.4630291,5.32986412 9.26776695,5.52512627 L3.96446609,10.8284271 C3.18341751,11.6094757 3.18341751,12.8758057 3.96446609,13.6568542 C4.74551468,14.4379028 6.01184464,14.4379028 6.79289322,13.6568542 L12.0961941,8.35355339 C13.4630291,6.98671837 13.4630291,4.77064094 12.0961941,3.40380592 C10.7293591,2.0369709 8.51328163,2.0369709 7.14644661,3.40380592 L2.55025253,8 C2.35499039,8.19526215 2.35499039,8.51184464 2.55025253,8.70710678 C2.74551468,8.90236893 3.06209717,8.90236893 3.25735931,8.70710678 Z"}))))),$t=se("trash",t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M432,144,403.33,419.74A32,32,0,0,1,371.55,448H140.46a32,32,0,0,1-31.78-28.26L80,144",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("rect",{x:"32",y:"64",width:"448",height:"80",rx:"16",ry:"16",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("line",{x1:"312",y1:"240",x2:"200",y2:"352",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("line",{x1:"312",y1:"352",x2:"200",y2:"240",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),Bt=se("download",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M3.5,13 L12.5,13 C12.7761424,13 13,13.2238576 13,13.5 C13,13.7454599 12.8231248,13.9496084 12.5898756,13.9919443 L12.5,14 L3.5,14 C3.22385763,14 3,13.7761424 3,13.5 C3,13.2545401 3.17687516,13.0503916 3.41012437,13.0080557 L3.5,13 L12.5,13 L3.5,13 Z M7.91012437,1.00805567 L8,1 C8.24545989,1 8.44960837,1.17687516 8.49194433,1.41012437 L8.5,1.5 L8.5,10.292 L11.1819805,7.6109127 C11.3555469,7.43734635 11.6249713,7.4180612 11.8198394,7.55305725 L11.8890873,7.6109127 C12.0626536,7.78447906 12.0819388,8.05390346 11.9469427,8.2487716 L11.8890873,8.31801948 L8.35355339,11.8535534 C8.17998704,12.0271197 7.91056264,12.0464049 7.7156945,11.9114088 L7.64644661,11.8535534 L4.1109127,8.31801948 C3.91565056,8.12275734 3.91565056,7.80617485 4.1109127,7.6109127 C4.28447906,7.43734635 4.55390346,7.4180612 4.7487716,7.55305725 L4.81801948,7.6109127 L7.5,10.292 L7.5,1.5 C7.5,1.25454011 7.67687516,1.05039163 7.91012437,1.00805567 L8,1 L7.91012437,1.00805567 Z"}))))),Tt=se("cancel",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M2.58859116,2.7156945 L2.64644661,2.64644661 C2.82001296,2.47288026 3.08943736,2.45359511 3.2843055,2.58859116 L3.35355339,2.64644661 L8,7.293 L12.6464466,2.64644661 C12.8417088,2.45118446 13.1582912,2.45118446 13.3535534,2.64644661 C13.5488155,2.84170876 13.5488155,3.15829124 13.3535534,3.35355339 L8.707,8 L13.3535534,12.6464466 C13.5271197,12.820013 13.5464049,13.0894374 13.4114088,13.2843055 L13.3535534,13.3535534 C13.179987,13.5271197 12.9105626,13.5464049 12.7156945,13.4114088 L12.6464466,13.3535534 L8,8.707 L3.35355339,13.3535534 C3.15829124,13.5488155 2.84170876,13.5488155 2.64644661,13.3535534 C2.45118446,13.1582912 2.45118446,12.8417088 2.64644661,12.6464466 L7.293,8 L2.64644661,3.35355339 C2.47288026,3.17998704 2.45359511,2.91056264 2.58859116,2.7156945 L2.64644661,2.64644661 L2.58859116,2.7156945 Z"}))))),Pt=se("retry",t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M320,146s24.36-12-64-12A160,160,0,1,0,416,294",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 32px;"}),t("polyline",{points:"256 58 336 138 256 218",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),Dt=j([b("progress",{display:"inline-block"},[b("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),I("line",`
 width: 100%;
 display: block;
 `,[b("progress-content",`
 display: flex;
 align-items: center;
 `,[b("progress-graph",{flex:1})]),b("progress-custom-content",{marginLeft:"14px"}),b("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[I("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),I("circle, dashboard",{width:"120px"},[b("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),b("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),b("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),I("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[b("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),b("progress-content",{position:"relative"}),b("progress-graph",{position:"relative"},[b("progress-graph-circle",[j("svg",{verticalAlign:"bottom"}),b("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[I("empty",{opacity:0})]),b("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),b("progress-graph-line",[I("indicator-inside",[b("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[b("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),b("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),I("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[b("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),b("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),b("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[b("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[I("processing",[j("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),j("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),Lt={success:t(_e,null),error:t($e,null),warning:t(Be,null),info:t(Te,null)},It=W({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:o}){const r=R(()=>re(e.height)),n=R(()=>e.railBorderRadius!==void 0?re(e.railBorderRadius):e.height!==void 0?re(e.height,{c:.5}):""),i=R(()=>e.fillBorderRadius!==void 0?re(e.fillBorderRadius):e.railBorderRadius!==void 0?re(e.railBorderRadius):e.height!==void 0?re(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:s,railColor:d,railStyle:u,percentage:c,unit:l,indicatorTextColor:a,status:f,showIndicator:S,fillColor:m,processing:x,clsPrefix:h}=e;return t("div",{class:`${h}-progress-content`,role:"none"},t("div",{class:`${h}-progress-graph`,"aria-hidden":!0},t("div",{class:[`${h}-progress-graph-line`,{[`${h}-progress-graph-line--indicator-${s}`]:!0}]},t("div",{class:`${h}-progress-graph-line-rail`,style:[{backgroundColor:d,height:r.value,borderRadius:n.value},u]},t("div",{class:[`${h}-progress-graph-line-fill`,x&&`${h}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:m,height:r.value,lineHeight:r.value,borderRadius:i.value}},s==="inside"?t("div",{class:`${h}-progress-graph-line-indicator`,style:{color:a}},c,l):null)))),S&&s==="outside"?t("div",null,o.default?t("div",{class:`${h}-progress-custom-content`,style:{color:a},role:"none"},o.default()):f==="default"?t("div",{role:"none",class:`${h}-progress-icon ${h}-progress-icon--as-text`,style:{color:a}},c,l):t("div",{class:`${h}-progress-icon`,"aria-hidden":!0},t(Y,{clsPrefix:h},{default:()=>Lt[f]}))):null)}}}),zt={success:t(_e,null),error:t($e,null),warning:t(Be,null),info:t(Te,null)},Ut=W({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:o}){function r(n,i,s){const{gapDegree:d,viewBoxWidth:u,strokeWidth:c}=e,l=50,a=0,f=l,S=0,m=2*l,x=50+c/2,h=`M ${x},${x} m ${a},${f}
      a ${l},${l} 0 1 1 ${S},${-m}
      a ${l},${l} 0 1 1 ${-S},${m}`,k=Math.PI*2*l,w={stroke:s,strokeDasharray:`${n/100*(k-d)}px ${u*8}px`,strokeDashoffset:`-${d/2}px`,transformOrigin:i?"center":void 0,transform:i?`rotate(${i}deg)`:void 0};return{pathString:h,pathStyle:w}}return()=>{const{fillColor:n,railColor:i,strokeWidth:s,offsetDegree:d,status:u,percentage:c,showIndicator:l,indicatorTextColor:a,unit:f,gapOffsetDegree:S,clsPrefix:m}=e,{pathString:x,pathStyle:h}=r(100,0,i),{pathString:k,pathStyle:w}=r(c,d,n),C=100+s;return t("div",{class:`${m}-progress-content`,role:"none"},t("div",{class:`${m}-progress-graph`,"aria-hidden":!0},t("div",{class:`${m}-progress-graph-circle`,style:{transform:S?`rotate(${S}deg)`:void 0}},t("svg",{viewBox:`0 0 ${C} ${C}`},t("g",null,t("path",{class:`${m}-progress-graph-circle-rail`,d:x,"stroke-width":s,"stroke-linecap":"round",fill:"none",style:h})),t("g",null,t("path",{class:[`${m}-progress-graph-circle-fill`,c===0&&`${m}-progress-graph-circle-fill--empty`],d:k,"stroke-width":s,"stroke-linecap":"round",fill:"none",style:w}))))),l?t("div",null,o.default?t("div",{class:`${m}-progress-custom-content`,role:"none"},o.default()):u!=="default"?t("div",{class:`${m}-progress-icon`,"aria-hidden":!0},t(Y,{clsPrefix:m},{default:()=>zt[u]})):t("div",{class:`${m}-progress-text`,style:{color:a},role:"none"},t("span",{class:`${m}-progress-text__percentage`},c),t("span",{class:`${m}-progress-text__unit`},f))):null)}}});function Ce(e,o,r=100){return`m ${r/2} ${r/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const Ft=W({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:o}){const r=R(()=>e.percentage.map((i,s)=>`${Math.PI*i/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*s)-e.circleGap*s)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:n,strokeWidth:i,circleGap:s,showIndicator:d,fillColor:u,railColor:c,railStyle:l,percentage:a,clsPrefix:f}=e;return t("div",{class:`${f}-progress-content`,role:"none"},t("div",{class:`${f}-progress-graph`,"aria-hidden":!0},t("div",{class:`${f}-progress-graph-circle`},t("svg",{viewBox:`0 0 ${n} ${n}`},a.map((S,m)=>t("g",{key:m},t("path",{class:`${f}-progress-graph-circle-rail`,d:Ce(n/2-i/2*(1+2*m)-s*m,i,n),"stroke-width":i,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:c[m]},l[m]]}),t("path",{class:[`${f}-progress-graph-circle-fill`,S===0&&`${f}-progress-graph-circle-fill--empty`],d:Ce(n/2-i/2*(1+2*m)-s*m,i,n),"stroke-width":i,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:r.value[m],strokeDashoffset:0,stroke:u[m]}})))))),d&&o.default?t("div",null,t("div",{class:`${f}-progress-text`},o.default())):null)}}}),Ot=Object.assign(Object.assign({},pe.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),Nt=W({name:"Progress",props:Ot,setup(e){const o=R(()=>e.indicatorPlacement||e.indicatorPosition),r=R(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:n,inlineThemeDisabled:i}=Pe(e),s=pe("Progress","-progress",Dt,Ye,e,n),d=R(()=>{const{status:c}=e,{common:{cubicBezierEaseInOut:l},self:{fontSize:a,fontSizeCircle:f,railColor:S,railHeight:m,iconSizeCircle:x,iconSizeLine:h,textColorCircle:k,textColorLineInner:w,textColorLineOuter:C,lineBgProcessing:p,fontWeightCircle:P,[me("iconColor",c)]:v,[me("fillColor",c)]:_}}=s.value;return{"--n-bezier":l,"--n-fill-color":_,"--n-font-size":a,"--n-font-size-circle":f,"--n-font-weight-circle":P,"--n-icon-color":v,"--n-icon-size-circle":x,"--n-icon-size-line":h,"--n-line-bg-processing":p,"--n-rail-color":S,"--n-rail-height":m,"--n-text-color-circle":k,"--n-text-color-line-inner":w,"--n-text-color-line-outer":C}}),u=i?De("progress",R(()=>e.status[0]),d,e):void 0;return{mergedClsPrefix:n,mergedIndicatorPlacement:o,gapDeg:r,cssVars:i?void 0:d,themeClass:u==null?void 0:u.themeClass,onRender:u==null?void 0:u.onRender}},render(){const{type:e,cssVars:o,indicatorTextColor:r,showIndicator:n,status:i,railColor:s,railStyle:d,color:u,percentage:c,viewBoxWidth:l,strokeWidth:a,mergedIndicatorPlacement:f,unit:S,borderRadius:m,fillBorderRadius:x,height:h,processing:k,circleGap:w,mergedClsPrefix:C,gapDeg:p,gapOffsetDegree:P,themeClass:v,$slots:_,onRender:L}=this;return L==null||L(),t("div",{class:[v,`${C}-progress`,`${C}-progress--${e}`,`${C}-progress--${i}`],style:o,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":c,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?t(Ut,{clsPrefix:C,status:i,showIndicator:n,indicatorTextColor:r,railColor:s,fillColor:u,railStyle:d,offsetDegree:this.offsetDegree,percentage:c,viewBoxWidth:l,strokeWidth:a,gapDegree:p===void 0?e==="dashboard"?75:0:p,gapOffsetDegree:P,unit:S},_):e==="line"?t(It,{clsPrefix:C,status:i,showIndicator:n,indicatorTextColor:r,railColor:s,fillColor:u,railStyle:d,percentage:c,processing:k,indicatorPlacement:f,unit:S,fillBorderRadius:x,railBorderRadius:m,height:h},_):e==="multiple-circle"?t(Ft,{clsPrefix:C,strokeWidth:a,railColor:s,fillColor:u,railStyle:d,viewBoxWidth:l,percentage:c,showIndicator:n,circleGap:w},_):null)}}),oe=Ze("n-upload"),je="__UPLOAD_DRAGGER__",jt=W({name:"UploadDragger",[je]:!0,setup(e,{slots:o}){const r=ce(oe,null);return r||ge("upload-dragger","`n-upload-dragger` must be placed inside `n-upload`."),()=>{const{mergedClsPrefixRef:{value:n},mergedDisabledRef:{value:i},maxReachedRef:{value:s}}=r;return t("div",{class:[`${n}-upload-dragger`,(i||s)&&`${n}-upload-dragger--disabled`]},o)}}});var Ae=globalThis&&globalThis.__awaiter||function(e,o,r,n){function i(s){return s instanceof r?s:new r(function(d){d(s)})}return new(r||(r=Promise))(function(s,d){function u(a){try{l(n.next(a))}catch(f){d(f)}}function c(a){try{l(n.throw(a))}catch(f){d(f)}}function l(a){a.done?s(a.value):i(a.value).then(u,c)}l((n=n.apply(e,o||[])).next())})};const Me=e=>e.includes("image/"),ke=(e="")=>{const o=e.split("/"),n=o[o.length-1].split(/#|\?/)[0];return(/\.[^./\\]*$/.exec(n)||[""])[0]},Re=/(webp|svg|png|gif|jpg|jpeg|jfif|bmp|dpg|ico)$/i,Ee=e=>{if(e.type)return Me(e.type);const o=ke(e.name||"");if(Re.test(o))return!0;const r=e.thumbnailUrl||e.url||"",n=ke(r);return!!(/^data:image\//.test(r)||Re.test(n))};function At(e){return Ae(this,void 0,void 0,function*(){return yield new Promise(o=>{if(!e.type||!Me(e.type)){o("");return}o(window.URL.createObjectURL(e))})})}const Mt=Je&&window.FileReader&&window.File;function Et(e){return e.isDirectory}function qt(e){return e.isFile}function Gt(e,o){return Ae(this,void 0,void 0,function*(){const r=[];let n,i=0;function s(){i++}function d(){i--,i||n(r)}function u(c){c.forEach(l=>{if(l){if(s(),o&&Et(l)){const a=l.createReader();s(),a.readEntries(f=>{u(f),d()},()=>{d()})}else qt(l)&&(s(),l.file(a=>{r.push({file:a,entry:l,source:"dnd"}),d()},()=>{d()}));d()}})}return yield new Promise(c=>{n=c,u(e)}),r})}function le(e){const{id:o,name:r,percentage:n,status:i,url:s,file:d,thumbnailUrl:u,type:c,fullPath:l,batchId:a}=e;return{id:o,name:r,percentage:n??null,status:i,url:s??null,file:d??null,thumbnailUrl:u??null,type:c??null,fullPath:l??null,batchId:a??null}}function Ht(e,o,r){return e=e.toLowerCase(),o=o.toLocaleLowerCase(),r=r.toLocaleLowerCase(),r.split(",").map(i=>i.trim()).filter(Boolean).some(i=>{if(i.startsWith(".")){if(e.endsWith(i))return!0}else if(i.includes("/")){const[s,d]=o.split("/"),[u,c]=i.split("/");if((u==="*"||s&&u&&u===s)&&(c==="*"||d&&c&&c===d))return!0}else return!0;return!1})}const Wt=(e,o)=>{if(!e)return;const r=document.createElement("a");r.href=e,o!==void 0&&(r.download=o),document.body.appendChild(r),r.click(),document.body.removeChild(r)},qe=W({name:"UploadTrigger",props:{abstract:Boolean},setup(e,{slots:o}){const r=ce(oe,null);r||ge("upload-trigger","`n-upload-trigger` must be placed inside `n-upload`.");const{mergedClsPrefixRef:n,mergedDisabledRef:i,maxReachedRef:s,listTypeRef:d,dragOverRef:u,openOpenFileDialog:c,draggerInsideRef:l,handleFileAddition:a,mergedDirectoryDndRef:f,triggerStyleRef:S}=r,m=R(()=>d.value==="image-card");function x(){i.value||s.value||c()}function h(p){p.preventDefault(),u.value=!0}function k(p){p.preventDefault(),u.value=!0}function w(p){p.preventDefault(),u.value=!1}function C(p){var P;if(p.preventDefault(),!l.value||i.value||s.value){u.value=!1;return}const v=(P=p.dataTransfer)===null||P===void 0?void 0:P.items;v!=null&&v.length?Gt(Array.from(v).map(_=>_.webkitGetAsEntry()),f.value).then(_=>{a(_)}).finally(()=>{u.value=!1}):u.value=!1}return()=>{var p;const{value:P}=n;return e.abstract?(p=o.default)===null||p===void 0?void 0:p.call(o,{handleClick:x,handleDrop:C,handleDragOver:h,handleDragEnter:k,handleDragLeave:w}):t("div",{class:[`${P}-upload-trigger`,(i.value||s.value)&&`${P}-upload-trigger--disabled`,m.value&&`${P}-upload-trigger--image-card`],style:S.value,onClick:x,onDrop:C,onDragover:h,onDragenter:k,onDragleave:w},m.value?t(jt,null,{default:()=>Qe(o.default,()=>[t(Y,{clsPrefix:P},{default:()=>t(et,null)})])}):o)}}}),Vt=W({name:"UploadProgress",props:{show:Boolean,percentage:{type:Number,required:!0},status:{type:String,required:!0}},setup(){return{mergedTheme:ce(oe).mergedThemeRef}},render(){return t(Le,null,{default:()=>this.show?t(Nt,{type:"line",showIndicator:!1,percentage:this.percentage,status:this.status,height:2,theme:this.mergedTheme.peers.Progress,themeOverrides:this.mergedTheme.peerOverrides.Progress}):null})}}),Xt=t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},t("g",{fill:"none"},t("path",{d:"M21.75 3A3.25 3.25 0 0 1 25 6.25v15.5A3.25 3.25 0 0 1 21.75 25H6.25A3.25 3.25 0 0 1 3 21.75V6.25A3.25 3.25 0 0 1 6.25 3h15.5zm.583 20.4l-7.807-7.68a.75.75 0 0 0-.968-.07l-.084.07l-7.808 7.68c.183.065.38.1.584.1h15.5c.204 0 .4-.035.583-.1l-7.807-7.68l7.807 7.68zM21.75 4.5H6.25A1.75 1.75 0 0 0 4.5 6.25v15.5c0 .208.036.408.103.593l7.82-7.692a2.25 2.25 0 0 1 3.026-.117l.129.117l7.82 7.692c.066-.185.102-.385.102-.593V6.25a1.75 1.75 0 0 0-1.75-1.75zm-3.25 3a2.5 2.5 0 1 1 0 5a2.5 2.5 0 0 1 0-5zm0 1.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2z",fill:"currentColor"}))),Kt=t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},t("g",{fill:"none"},t("path",{d:"M6.4 2A2.4 2.4 0 0 0 4 4.4v19.2A2.4 2.4 0 0 0 6.4 26h15.2a2.4 2.4 0 0 0 2.4-2.4V11.578c0-.729-.29-1.428-.805-1.944l-6.931-6.931A2.4 2.4 0 0 0 14.567 2H6.4zm-.9 2.4a.9.9 0 0 1 .9-.9H14V10a2 2 0 0 0 2 2h6.5v11.6a.9.9 0 0 1-.9.9H6.4a.9.9 0 0 1-.9-.9V4.4zm16.44 6.1H16a.5.5 0 0 1-.5-.5V4.06l6.44 6.44z",fill:"currentColor"})));var Yt=globalThis&&globalThis.__awaiter||function(e,o,r,n){function i(s){return s instanceof r?s:new r(function(d){d(s)})}return new(r||(r=Promise))(function(s,d){function u(a){try{l(n.next(a))}catch(f){d(f)}}function c(a){try{l(n.throw(a))}catch(f){d(f)}}function l(a){a.done?s(a.value):i(a.value).then(u,c)}l((n=n.apply(e,o||[])).next())})};const ue={paddingMedium:"0 3px",heightMedium:"24px",iconSizeMedium:"18px"},Zt=W({name:"UploadFile",props:{clsPrefix:{type:String,required:!0},file:{type:Object,required:!0},listType:{type:String,required:!0}},setup(e){const o=ce(oe),r=E(null),n=E(""),i=R(()=>{const{file:v}=e;return v.status==="finished"?"success":v.status==="error"?"error":"info"}),s=R(()=>{const{file:v}=e;if(v.status==="error")return"error"}),d=R(()=>{const{file:v}=e;return v.status==="uploading"}),u=R(()=>{if(!o.showCancelButtonRef.value)return!1;const{file:v}=e;return["uploading","pending","error"].includes(v.status)}),c=R(()=>{if(!o.showRemoveButtonRef.value)return!1;const{file:v}=e;return["finished"].includes(v.status)}),l=R(()=>{if(!o.showDownloadButtonRef.value)return!1;const{file:v}=e;return["finished"].includes(v.status)}),a=R(()=>{if(!o.showRetryButtonRef.value)return!1;const{file:v}=e;return["error"].includes(v.status)}),f=tt(()=>n.value||e.file.thumbnailUrl||e.file.url),S=R(()=>{if(!o.showPreviewButtonRef.value)return!1;const{file:{status:v},listType:_}=e;return["finished"].includes(v)&&f.value&&_==="image-card"});function m(){o.submit(e.file.id)}function x(v){v.preventDefault();const{file:_}=e;["finished","pending","error"].includes(_.status)?k(_):["uploading"].includes(_.status)?C(_):at("upload","The button clicked type is unknown.")}function h(v){v.preventDefault(),w(e.file)}function k(v){const{xhrMap:_,doChange:L,onRemoveRef:{value:te},mergedFileListRef:{value:y}}=o;Promise.resolve(te?te({file:Object.assign({},v),fileList:y}):!0).then(z=>{if(z===!1)return;const U=Object.assign({},v,{status:"removed"});_.delete(v.id),L(U,void 0,{remove:!0})})}function w(v){const{onDownloadRef:{value:_}}=o;Promise.resolve(_?_(Object.assign({},v)):!0).then(L=>{L!==!1&&Wt(v.url,v.name)})}function C(v){const{xhrMap:_}=o,L=_.get(v.id);L==null||L.abort(),k(Object.assign({},v))}function p(){const{onPreviewRef:{value:v}}=o;if(v)v(e.file);else if(e.listType==="image-card"){const{value:_}=r;if(!_)return;_.click()}}const P=()=>Yt(this,void 0,void 0,function*(){const{listType:v}=e;v!=="image"&&v!=="image-card"||o.shouldUseThumbnailUrlRef.value(e.file)&&(n.value=yield o.getFileThumbnailUrlResolver(e.file))});return rt(()=>{P()}),{mergedTheme:o.mergedThemeRef,progressStatus:i,buttonType:s,showProgress:d,disabled:o.mergedDisabledRef,showCancelButton:u,showRemoveButton:c,showDownloadButton:l,showRetryButton:a,showPreviewButton:S,mergedThumbnailUrl:f,shouldUseThumbnailUrl:o.shouldUseThumbnailUrlRef,renderIcon:o.renderIconRef,imageRef:r,handleRemoveOrCancelClick:x,handleDownloadClick:h,handleRetryClick:m,handlePreviewClick:p}},render(){const{clsPrefix:e,mergedTheme:o,listType:r,file:n,renderIcon:i}=this;let s;const d=r==="image";d||r==="image-card"?s=!this.shouldUseThumbnailUrl(n)||!this.mergedThumbnailUrl?t("span",{class:`${e}-upload-file-info__thumbnail`},i?i(n):Ee(n)?t(Y,{clsPrefix:e},{default:()=>Xt}):t(Y,{clsPrefix:e},{default:()=>Kt})):t("a",{rel:"noopener noreferer",target:"_blank",href:n.url||void 0,class:`${e}-upload-file-info__thumbnail`,onClick:this.handlePreviewClick},r==="image-card"?t(nt,{src:this.mergedThumbnailUrl||void 0,previewSrc:n.url||void 0,alt:n.name,ref:"imageRef"}):t("img",{src:this.mergedThumbnailUrl||void 0,alt:n.name})):s=t("span",{class:`${e}-upload-file-info__thumbnail`},i?i(n):t(Y,{clsPrefix:e},{default:()=>t(_t,null)}));const c=t(Vt,{show:this.showProgress,percentage:n.percentage||0,status:this.progressStatus}),l=r==="text"||r==="image";return t("div",{class:[`${e}-upload-file`,`${e}-upload-file--${this.progressStatus}-status`,n.url&&n.status!=="error"&&r!=="image-card"&&`${e}-upload-file--with-url`,`${e}-upload-file--${r}-type`]},t("div",{class:`${e}-upload-file-info`},s,t("div",{class:`${e}-upload-file-info__name`},l&&(n.url&&n.status!=="error"?t("a",{rel:"noopener noreferer",target:"_blank",href:n.url||void 0,onClick:this.handlePreviewClick},n.name):t("span",{onClick:this.handlePreviewClick},n.name)),d&&c),t("div",{class:[`${e}-upload-file-info__action`,`${e}-upload-file-info__action--${r}-type`]},this.showPreviewButton?t(Q,{key:"preview",quaternary:!0,type:this.buttonType,onClick:this.handlePreviewClick,theme:o.peers.Button,themeOverrides:o.peerOverrides.Button,builtinThemeOverrides:ue},{icon:()=>t(Y,{clsPrefix:e},{default:()=>t(ot,null)})}):null,(this.showRemoveButton||this.showCancelButton)&&!this.disabled&&t(Q,{key:"cancelOrTrash",theme:o.peers.Button,themeOverrides:o.peerOverrides.Button,quaternary:!0,builtinThemeOverrides:ue,type:this.buttonType,onClick:this.handleRemoveOrCancelClick},{icon:()=>t(it,null,{default:()=>this.showRemoveButton?t(Y,{clsPrefix:e,key:"trash"},{default:()=>t($t,null)}):t(Y,{clsPrefix:e,key:"cancel"},{default:()=>t(Tt,null)})})}),this.showRetryButton&&!this.disabled&&t(Q,{key:"retry",quaternary:!0,type:this.buttonType,onClick:this.handleRetryClick,theme:o.peers.Button,themeOverrides:o.peerOverrides.Button,builtinThemeOverrides:ue},{icon:()=>t(Y,{clsPrefix:e},{default:()=>t(Pt,null)})}),this.showDownloadButton?t(Q,{key:"download",quaternary:!0,type:this.buttonType,onClick:this.handleDownloadClick,theme:o.peers.Button,themeOverrides:o.peerOverrides.Button,builtinThemeOverrides:ue},{icon:()=>t(Y,{clsPrefix:e},{default:()=>t(Bt,null)})}):null)),!d&&c)}}),Jt=W({name:"UploadFileList",setup(e,{slots:o}){const r=ce(oe,null);r||ge("upload-file-list","`n-upload-file-list` must be placed inside `n-upload`.");const{abstractRef:n,mergedClsPrefixRef:i,listTypeRef:s,mergedFileListRef:d,fileListStyleRef:u,cssVarsRef:c,themeClassRef:l,maxReachedRef:a,showTriggerRef:f,imageGroupPropsRef:S}=r,m=R(()=>s.value==="image-card"),x=()=>d.value.map(k=>t(Zt,{clsPrefix:i.value,key:k.id,file:k,listType:s.value})),h=()=>m.value?t(lt,Object.assign({},S.value),{default:x}):t(Le,{group:!0},{default:x});return()=>{const{value:k}=i,{value:w}=n;return t("div",{class:[`${k}-upload-file-list`,m.value&&`${k}-upload-file-list--grid`,w?l==null?void 0:l.value:void 0],style:[w&&c?c.value:"",u.value]},h(),f.value&&!a.value&&m.value&&t(qe,null,o))}}}),Qt=j([b("upload","width: 100%;",[I("dragger-inside",[b("upload-trigger",`
 display: block;
 `)]),I("drag-over",[b("upload-dragger",`
 border: var(--n-dragger-border-hover);
 `)])]),b("upload-dragger",`
 cursor: pointer;
 box-sizing: border-box;
 width: 100%;
 text-align: center;
 border-radius: var(--n-border-radius);
 padding: 24px;
 opacity: 1;
 transition:
 opacity .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-dragger-color);
 border: var(--n-dragger-border);
 `,[j("&:hover",`
 border: var(--n-dragger-border-hover);
 `),I("disabled",`
 cursor: not-allowed;
 `)]),b("upload-trigger",`
 display: inline-block;
 box-sizing: border-box;
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[j("+",[b("upload-file-list","margin-top: 8px;")]),I("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `),I("image-card",`
 width: 96px;
 height: 96px;
 `,[b("base-icon",`
 font-size: 24px;
 `),b("upload-dragger",`
 padding: 0;
 height: 100%;
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `)])]),b("upload-file-list",`
 line-height: var(--n-line-height);
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[j("a, img","outline: none;"),I("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `,[b("upload-file","cursor: not-allowed;")]),I("grid",`
 display: grid;
 grid-template-columns: repeat(auto-fill, 96px);
 grid-gap: 8px;
 margin-top: 0;
 `),b("upload-file",`
 display: block;
 box-sizing: border-box;
 cursor: default;
 padding: 0px 12px 0 6px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `,[ve(),b("progress",[ve({foldPadding:!0})]),j("&:hover",`
 background-color: var(--n-item-color-hover);
 `,[b("upload-file-info",[K("action",`
 opacity: 1;
 `)])]),I("image-type",`
 border-radius: var(--n-border-radius);
 text-decoration: underline;
 text-decoration-color: #0000;
 `,[b("upload-file-info",`
 padding-top: 0px;
 padding-bottom: 0px;
 width: 100%;
 height: 100%;
 display: flex;
 justify-content: space-between;
 align-items: center;
 padding: 6px 0;
 `,[b("progress",`
 padding: 2px 0;
 margin-bottom: 0;
 `),K("name",`
 padding: 0 8px;
 `),K("thumbnail",`
 width: 32px;
 height: 32px;
 font-size: 28px;
 display: flex;
 justify-content: center;
 align-items: center;
 `,[j("img",`
 width: 100%;
 `)])])]),I("text-type",[b("progress",`
 box-sizing: border-box;
 padding-bottom: 6px;
 margin-bottom: 6px;
 `)]),I("image-card-type",`
 position: relative;
 width: 96px;
 height: 96px;
 border: var(--n-item-border-image-card);
 border-radius: var(--n-border-radius);
 padding: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 overflow: hidden;
 `,[b("progress",`
 position: absolute;
 left: 8px;
 bottom: 8px;
 right: 8px;
 width: unset;
 `),b("upload-file-info",`
 padding: 0;
 width: 100%;
 height: 100%;
 `,[K("thumbnail",`
 width: 100%;
 height: 100%;
 display: flex;
 flex-direction: column;
 align-items: center;
 justify-content: center;
 font-size: 36px;
 `,[j("img",`
 width: 100%;
 `)])]),j("&::before",`
 position: absolute;
 z-index: 1;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 opacity: 0;
 transition: opacity .2s var(--n-bezier);
 content: "";
 `),j("&:hover",[j("&::before","opacity: 1;"),b("upload-file-info",[K("thumbnail","opacity: .12;")])])]),I("error-status",[j("&:hover",`
 background-color: var(--n-item-color-hover-error);
 `),b("upload-file-info",[K("name","color: var(--n-item-text-color-error);"),K("thumbnail","color: var(--n-item-text-color-error);")]),I("image-card-type",`
 border: var(--n-item-border-image-card-error);
 `)]),I("with-url",`
 cursor: pointer;
 `,[b("upload-file-info",[K("name",`
 color: var(--n-item-text-color-success);
 text-decoration-color: var(--n-item-text-color-success);
 `,[j("a",`
 text-decoration: underline;
 `)])])]),b("upload-file-info",`
 position: relative;
 padding-top: 6px;
 padding-bottom: 6px;
 display: flex;
 flex-wrap: nowrap;
 `,[K("thumbnail",`
 font-size: 18px;
 opacity: 1;
 transition: opacity .2s var(--n-bezier);
 color: var(--n-item-icon-color);
 `,[b("base-icon",`
 margin-right: 2px;
 vertical-align: middle;
 transition: color .3s var(--n-bezier);
 `)]),K("action",`
 padding-top: inherit;
 padding-bottom: inherit;
 position: absolute;
 right: 0;
 top: 0;
 bottom: 0;
 width: 80px;
 display: flex;
 align-items: center;
 transition: opacity .2s var(--n-bezier);
 justify-content: flex-end;
 opacity: 0;
 `,[b("button",[j("&:not(:last-child)",{marginRight:"4px"}),b("base-icon",[j("svg",[st()])])]),I("image-type",`
 position: relative;
 max-width: 80px;
 width: auto;
 `),I("image-card-type",`
 z-index: 2;
 position: absolute;
 width: 100%;
 height: 100%;
 left: 0;
 right: 0;
 bottom: 0;
 top: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 `)]),K("name",`
 color: var(--n-item-text-color);
 flex: 1;
 display: flex;
 justify-content: center;
 text-overflow: ellipsis;
 overflow: hidden;
 flex-direction: column;
 text-decoration-color: #0000;
 font-size: var(--n-font-size);
 transition:
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier); 
 `,[j("a",`
 color: inherit;
 text-decoration: underline;
 `)])])])]),b("upload-file-input",`
 display: block;
 width: 0;
 height: 0;
 opacity: 0;
 `)]);var Se=globalThis&&globalThis.__awaiter||function(e,o,r,n){function i(s){return s instanceof r?s:new r(function(d){d(s)})}return new(r||(r=Promise))(function(s,d){function u(a){try{l(n.next(a))}catch(f){d(f)}}function c(a){try{l(n.throw(a))}catch(f){d(f)}}function l(a){a.done?s(a.value):i(a.value).then(u,c)}l((n=n.apply(e,o||[])).next())})};function er(e,o,r){const{doChange:n,xhrMap:i}=e;let s=0;function d(c){var l;let a=Object.assign({},o,{status:"error",percentage:s});i.delete(o.id),a=le(((l=e.onError)===null||l===void 0?void 0:l.call(e,{file:a,event:c}))||a),n(a,c)}function u(c){var l;if(e.isErrorState){if(e.isErrorState(r)){d(c);return}}else if(r.status<200||r.status>=300){d(c);return}let a=Object.assign({},o,{status:"finished",percentage:s});i.delete(o.id),a=le(((l=e.onFinish)===null||l===void 0?void 0:l.call(e,{file:a,event:c}))||a),n(a,c)}return{handleXHRLoad:u,handleXHRError:d,handleXHRAbort(c){const l=Object.assign({},o,{status:"removed",file:null,percentage:s});i.delete(o.id),n(l,c)},handleXHRProgress(c){const l=Object.assign({},o,{status:"uploading"});if(c.lengthComputable){const a=Math.ceil(c.loaded/c.total*100);l.percentage=a,s=a}n(l,c)}}}function tr(e){const{inst:o,file:r,data:n,headers:i,withCredentials:s,action:d,customRequest:u}=e,{doChange:c}=e.inst;let l=0;u({file:r,data:n,headers:i,withCredentials:s,action:d,onProgress(a){const f=Object.assign({},r,{status:"uploading"}),S=a.percent;f.percentage=S,l=S,c(f)},onFinish(){var a;let f=Object.assign({},r,{status:"finished",percentage:l});f=le(((a=o.onFinish)===null||a===void 0?void 0:a.call(o,{file:f}))||f),c(f)},onError(){var a;let f=Object.assign({},r,{status:"error",percentage:l});f=le(((a=o.onError)===null||a===void 0?void 0:a.call(o,{file:f}))||f),c(f)}})}function rr(e,o,r){const n=er(e,o,r);r.onabort=n.handleXHRAbort,r.onerror=n.handleXHRError,r.onload=n.handleXHRLoad,r.upload&&(r.upload.onprogress=n.handleXHRProgress)}function Ge(e,o){return typeof e=="function"?e({file:o}):e||{}}function nr(e,o,r){const n=Ge(o,r);n&&Object.keys(n).forEach(i=>{e.setRequestHeader(i,n[i])})}function or(e,o,r){const n=Ge(o,r);n&&Object.keys(n).forEach(i=>{e.append(i,n[i])})}function ir(e,o,r,{method:n,action:i,withCredentials:s,responseType:d,headers:u,data:c}){const l=new XMLHttpRequest;l.responseType=d,e.xhrMap.set(r.id,l),l.withCredentials=s;const a=new FormData;if(or(a,c,r),a.append(o,r.file),rr(e,r,l),i!==void 0){l.open(n.toUpperCase(),i),nr(l,u,r),l.send(a);const f=Object.assign({},r,{status:"uploading"});e.doChange(f)}}const ar=Object.assign(Object.assign({},pe.props),{name:{type:String,default:"file"},accept:String,action:String,customRequest:Function,directory:Boolean,directoryDnd:{type:Boolean,default:void 0},method:{type:String,default:"POST"},multiple:Boolean,showFileList:{type:Boolean,default:!0},data:[Object,Function],headers:[Object,Function],withCredentials:Boolean,responseType:{type:String,default:""},disabled:{type:Boolean,default:void 0},onChange:Function,onRemove:Function,onFinish:Function,onError:Function,onBeforeUpload:Function,isErrorState:Function,onDownload:Function,defaultUpload:{type:Boolean,default:!0},fileList:Array,"onUpdate:fileList":[Function,Array],onUpdateFileList:[Function,Array],fileListStyle:[String,Object],defaultFileList:{type:Array,default:()=>[]},showCancelButton:{type:Boolean,default:!0},showRemoveButton:{type:Boolean,default:!0},showDownloadButton:Boolean,showRetryButton:{type:Boolean,default:!0},showPreviewButton:{type:Boolean,default:!0},listType:{type:String,default:"text"},onPreview:Function,shouldUseThumbnailUrl:{type:Function,default:e=>Mt?Ee(e):!1},createThumbnailUrl:Function,abstract:Boolean,max:Number,showTrigger:{type:Boolean,default:!0},imageGroupProps:Object,inputProps:Object,triggerStyle:[String,Object],renderIcon:Object}),Gr=W({name:"Upload",props:ar,setup(e){e.abstract&&e.listType==="image-card"&&ge("upload","when the list-type is image-card, abstract is not supported.");const{mergedClsPrefixRef:o,inlineThemeDisabled:r}=Pe(e),n=pe("Upload","-upload",Qt,pt,e,o),i=ct(e),s=R(()=>{const{max:y}=e;return y!==void 0?m.value.length>=y:!1}),d=E(e.defaultFileList),u=M(e,"fileList"),c=E(null),l={value:!1},a=E(!1),f=new Map,S=dt(u,d),m=R(()=>S.value.map(le));function x(){var y;(y=c.value)===null||y===void 0||y.click()}function h(y){const z=y.target;C(z.files?Array.from(z.files).map(U=>({file:U,entry:null,source:"input"})):null,y),z.value=""}function k(y){const{"onUpdate:fileList":z,onUpdateFileList:U}=e;z&&be(z,y),U&&be(U,y),d.value=y}const w=R(()=>e.multiple||e.directory);function C(y,z){if(!y||y.length===0)return;const{onBeforeUpload:U}=e;y=w.value?y:[y[0]];const{max:V,accept:H}=e;y=y.filter(({file:$,source:T})=>T==="dnd"&&(H!=null&&H.trim())?Ht($.name,$.type,H):!0),V&&(y=y.slice(0,V-m.value.length));const G=ye();Promise.all(y.map(({file:$,entry:T})=>Se(this,void 0,void 0,function*(){var N;const Z={id:ye(),batchId:G,name:$.name,status:"pending",percentage:0,file:$,url:null,type:$.type,thumbnailUrl:null,fullPath:(N=T==null?void 0:T.fullPath)!==null&&N!==void 0?N:`/${$.webkitRelativePath||$.name}`};return!U||(yield U({file:Z,fileList:m.value}))!==!1?Z:null}))).then($=>Se(this,void 0,void 0,function*(){let T=Promise.resolve();return $.forEach(N=>{T=T.then(Ie).then(()=>{N&&P(N,z,{append:!0})})}),yield T})).then(()=>{e.defaultUpload&&p()})}function p(y){const{method:z,action:U,withCredentials:V,headers:H,data:G,name:$}=e,T=y!==void 0?m.value.filter(Z=>Z.id===y):m.value,N=y!==void 0;T.forEach(Z=>{const{status:de}=Z;(de==="pending"||de==="error"&&N)&&(e.customRequest?tr({inst:{doChange:P,xhrMap:f,onFinish:e.onFinish,onError:e.onError},file:Z,action:U,withCredentials:V,headers:H,data:G,customRequest:e.customRequest}):ir({doChange:P,xhrMap:f,onFinish:e.onFinish,onError:e.onError,isErrorState:e.isErrorState},$,Z,{method:z,action:U,withCredentials:V,responseType:e.responseType,headers:H,data:G}))})}const P=(y,z,U={append:!1,remove:!1})=>{const{append:V,remove:H}=U,G=Array.from(m.value),$=G.findIndex(T=>T.id===y.id);if(V||H||~$){V?G.push(y):H?G.splice($,1):G.splice($,1,y);const{onChange:T}=e;T&&T({file:y,fileList:G,event:z}),k(G)}};function v(y){var z;if(y.thumbnailUrl)return y.thumbnailUrl;const{createThumbnailUrl:U}=e;return U?(z=U(y.file,y))!==null&&z!==void 0?z:y.url||"":y.url?y.url:y.file?At(y.file):""}const _=R(()=>{const{common:{cubicBezierEaseInOut:y},self:{draggerColor:z,draggerBorder:U,draggerBorderHover:V,itemColorHover:H,itemColorHoverError:G,itemTextColorError:$,itemTextColorSuccess:T,itemTextColor:N,itemIconColor:Z,itemDisabledOpacity:de,lineHeight:He,borderRadius:We,fontSize:Ve,itemBorderImageCardError:Xe,itemBorderImageCard:Ke}}=n.value;return{"--n-bezier":y,"--n-border-radius":We,"--n-dragger-border":U,"--n-dragger-border-hover":V,"--n-dragger-color":z,"--n-font-size":Ve,"--n-item-color-hover":H,"--n-item-color-hover-error":G,"--n-item-disabled-opacity":de,"--n-item-icon-color":Z,"--n-item-text-color":N,"--n-item-text-color-error":$,"--n-item-text-color-success":T,"--n-line-height":He,"--n-item-border-image-card-error":Xe,"--n-item-border-image-card":Ke}}),L=r?De("upload",void 0,_,e):void 0;ut(oe,{mergedClsPrefixRef:o,mergedThemeRef:n,showCancelButtonRef:M(e,"showCancelButton"),showDownloadButtonRef:M(e,"showDownloadButton"),showRemoveButtonRef:M(e,"showRemoveButton"),showRetryButtonRef:M(e,"showRetryButton"),onRemoveRef:M(e,"onRemove"),onDownloadRef:M(e,"onDownload"),mergedFileListRef:m,triggerStyleRef:M(e,"triggerStyle"),shouldUseThumbnailUrlRef:M(e,"shouldUseThumbnailUrl"),renderIconRef:M(e,"renderIcon"),xhrMap:f,submit:p,doChange:P,showPreviewButtonRef:M(e,"showPreviewButton"),onPreviewRef:M(e,"onPreview"),getFileThumbnailUrlResolver:v,listTypeRef:M(e,"listType"),dragOverRef:a,openOpenFileDialog:x,draggerInsideRef:l,handleFileAddition:C,mergedDisabledRef:i.mergedDisabledRef,maxReachedRef:s,fileListStyleRef:M(e,"fileListStyle"),abstractRef:M(e,"abstract"),acceptRef:M(e,"accept"),cssVarsRef:r?void 0:_,themeClassRef:L==null?void 0:L.themeClass,onRender:L==null?void 0:L.onRender,showTriggerRef:M(e,"showTrigger"),imageGroupPropsRef:M(e,"imageGroupProps"),mergedDirectoryDndRef:R(()=>{var y;return(y=e.directoryDnd)!==null&&y!==void 0?y:e.directory})});const te={clear:()=>{d.value=[]},submit:p,openOpenFileDialog:x};return Object.assign({mergedClsPrefix:o,draggerInsideRef:l,inputElRef:c,mergedTheme:n,dragOver:a,mergedMultiple:w,cssVars:r?void 0:_,themeClass:L==null?void 0:L.themeClass,onRender:L==null?void 0:L.onRender,handleFileInputChange:h},te)},render(){var e,o;const{draggerInsideRef:r,mergedClsPrefix:n,$slots:i,directory:s,onRender:d}=this;if(i.default&&!this.abstract){const c=i.default()[0];!((e=c==null?void 0:c.type)===null||e===void 0)&&e[je]&&(r.value=!0)}const u=t("input",Object.assign({},this.inputProps,{ref:"inputElRef",type:"file",class:`${n}-upload-file-input`,accept:this.accept,multiple:this.mergedMultiple,onChange:this.handleFileInputChange,webkitdirectory:s||void 0,directory:s||void 0}));return this.abstract?t(ie,null,(o=i.default)===null||o===void 0?void 0:o.call(i),t(ft,{to:"body"},u)):(d==null||d(),t("div",{class:[`${n}-upload`,r.value&&`${n}-upload--dragger-inside`,this.dragOver&&`${n}-upload--drag-over`,this.themeClass],style:this.cssVars},u,this.showTrigger&&this.listType!=="image-card"&&t(qe,null,i),this.showFileList&&t(Jt,null,i)))}});function lr(e,o){let r;return(...n)=>{const i=()=>{clearTimeout(r),e(...n)};clearTimeout(r),r=setTimeout(i,o)}}const sr={class:"mb-2 text-xs text-neutral-400 font-bold"},cr={class:"ml-1"},dr=["onClick"],ur={class:"relative flex-1 overflow-hidden break-all text-ellipsis whitespace-nowrap"},fr={key:1},pr={key:0,class:"absolute z-10 flex visible right-1"},gr=["onClick"],hr={class:"p-1"},mr={key:0,class:"p-1"},vr={class:"p-1"},fe=W({__name:"ListItem",props:{dataSources:null,title:null},emits:["update","delete","sticky","select"],setup(e,{emit:o}){const r=e,n=r.dataSources,i=he();async function s(x){o("select",x)}function d(x,h,k){k==null||k.stopPropagation(),x.isEdit=h}async function u(x,h){h==null||h.stopPropagation(),await i.updateGroupInfo({isSticky:!x.isSticky,groupId:x.uuid}),await i.queryMyGroup()}async function c(x,h){h==null||h.stopPropagation(),o("delete",x)}const l=lr(c,600);async function a(x){const{uuid:h,title:k}=x;x.isEdit=!1,await i.updateGroupInfo({groupId:h,title:k}),await i.queryMyGroup()}async function f(x,h){h==null||h.stopPropagation(),h.key==="Enter"&&a(x)}function S(x,h){h==null||h.stopPropagation(),a(x)}function m(x){return i.active===x}return(x,h)=>{var k;return D(),F(ie,null,[O("p",sr,[X(ee(r.title)+" ",1),O("span",cr,"("+ee((k=g(n))==null?void 0:k.length)+")",1)]),(D(!0),F(ie,null,gt(g(n),w=>(D(),F("div",{key:`${w.uuid}`},[O("a",{class:ht(["relative flex items-center gap-3 px-3 py-2.5 break-all border rounded-md cursor-pointer hover:bg-neutral-100 group dark:border-neutral-800 dark:hover:bg-[#24272e]",m(w.uuid)&&["border-[#3076FD]","bg-neutral-100","text-[#3076FD]","dark:bg-[#24272e]","dark:border-[#3076fd]","pr-20"]]),onClick:C=>s(w)},[O("span",null,[B(g(A),{icon:w.isSticky?"ri:pushpin-2-line":w.appId?"icon-park-outline:application-one":"ri:message-3-line"},null,8,["icon"])]),O("div",ur,[w.isEdit?(D(),ne(g(ze),{key:0,value:w.title,"onUpdate:value":C=>w.title=C,size:"tiny",onKeypress:C=>f(w,C)},null,8,["value","onUpdate:value","onKeypress"])):(D(),F("span",fr,ee(w.title),1))]),m(w.uuid)?(D(),F("div",pr,[w.isEdit?(D(),F("button",{key:0,class:"p-1",onClick:C=>S(w,C)},[B(g(A),{icon:"ri:save-line"})],8,gr)):(D(),F(ie,{key:1},[O("button",hr,[B(g(A),{icon:w.isSticky?"ri:unpin-line":"ri:pushpin-line",onClick:C=>u(w,C)},null,8,["icon","onClick"])]),w.appId?q("",!0):(D(),F("button",mr,[B(g(A),{icon:"ri:edit-line",onClick:C=>d(w,!0,C)},null,8,["onClick"])])),B(g(Rt),{placement:"bottom",onPositiveClick:C=>g(l)(w,C)},{trigger:J(()=>[O("button",vr,[B(g(A),{icon:"ri:delete-bin-line"})])]),default:J(()=>[X(" "+ee(x.$t("chat.deleteHistoryConfirm")),1)]),_:2},1032,["onPositiveClick"])],64))])):q("",!0)],10,dr)]))),128))],64)}}}),yr={class:"flex flex-col gap-3 text-sm"},br={key:0,class:"flex flex-col items-center mt-4 text-center text-neutral-300"},xr=W({__name:"List",setup(e){const{isMobile:o}=Ue(),r=Fe(),n=mt(),i=Oe(),s=he(),d=Ne(),u=E(100),c=R(()=>s.groupList),l=R(()=>s.groupKeyWord);ae(c,()=>u.value=u.value+1),ae(l,()=>u.value=u.value+1),R(()=>d.isLogin);function a(p){const v=new Date(p).getTime()+8*60*60*1e3;return new Date(v).getTime()}const f=new Date().setHours(0,0,0,0),S=R(()=>c.value.filter(p=>l.value?p.title.includes(l.value)&&p.isSticky:p.isSticky)),m=R(()=>c.value.filter(p=>l.value?p.title.includes(l.value)&&!p.isSticky&&p.appId:!p.isSticky&&p.appId)),x=R(()=>c.value.filter(p=>l.value?p.title.includes(l.value)&&!p.isSticky&&!p.appId&&a(p.createdAt)>=f:!p.isSticky&&!p.appId&&a(p.createdAt)>=f)),h=R(()=>c.value.filter(p=>l.value?p.title.includes(l.value)&&!p.isSticky&&!p.appId&&a(p.createdAt)<f:!p.isSticky&&!p.appId&&a(p.createdAt)<f));async function k(p){const{uuid:P}=p;C(P)||(await s.setActiveGroup(P),n.name!=="Chat"&&r.push("/chat"),o.value&&i.setSiderCollapsed(!0))}async function w(p){event==null||event.stopPropagation(),await s.deleteGroup(p),await s.queryMyGroup(),o.value&&i.setSiderCollapsed(!0)}function C(p){return s.active===p}return vt(()=>{s.queryMyGroup()}),(p,P)=>(D(),ne(g(yt),{class:"px-4"},{default:J(()=>[O("div",yr,[g(c).length?(D(),F(ie,{key:1},[g(S).length?(D(),ne(fe,{key:1e3+u.value,title:"置顶","data-sources":g(S),onSelect:k,onDelete:w},null,8,["data-sources"])):q("",!0),g(m).length?(D(),ne(fe,{key:2e3+u.value,title:"应用分类组","data-sources":g(m),onSelect:k,onDelete:w},null,8,["data-sources"])):q("",!0),g(x).length?(D(),ne(fe,{key:3e3+u.value,title:"今天","data-sources":g(x),onSelect:k,onDelete:w},null,8,["data-sources"])):q("",!0),g(h).length?(D(),ne(fe,{key:4e3+u.value,title:"其他","data-sources":g(h),onSelect:k,onDelete:w},null,8,["data-sources"])):q("",!0)],64)):(D(),F("div",br,[B(g(A),{icon:"ri:inbox-line",class:"mb-2 text-3xl"}),O("span",null,ee(p.$t("common.noData")),1)]))])]),_:1}))}}),wr={class:"flex flex-col h-full flex-1 min-h-0"},Cr={key:0,class:"flex h-14 items-center space-x-2 bg-[#fafbfc] dark:bg-[#18181c]"},kr={class:"flex-1"},Rr={key:1,class:"flex h-14 items-center space-x-2 px-2 bg-[#fafbfc] dark:bg-[#18181c]"},Sr={class:"flex-1"},_r={class:"flex-1 min-h-0 pb-4 overflow-hidden"},$r={key:2,class:"px-6 py-2 flex items-center border-t dark:border-t-neutral-800"},Br={class:"p-4 border-t dark:border-t-neutral-800 flex flex-col"},Tr={key:0,class:"my-1 flex items-center select-none"},Pr={key:1,class:"my-1 flex items-center select-none"},Dr={key:2,class:"my-1 flex items-center select-none"},Lr={key:3,class:"my-1 flex items-center select-none"},Ir={key:4,class:"my-1 flex items-center select-none"},zr={key:5,class:"my-1 flex items-center select-none"},Ur={class:"flex justify-between my-3"},Fr=O("span",{class:"mr-2"},"公告栏",-1),Or=O("span",{class:"mr-3"},"工作台",-1),Nr={class:"flex justify-betweenx"},jr=O("span",{class:"mr-3"},"清空全部非置顶会话",-1),Hr=W({__name:"index",setup(e){const o=bt(),r=Fe(),n=Oe(),i=he(),s=Ne();xt();const d=E(null),u=E(null),c=R(()=>s.userBalance),l=wt(),a=R(()=>i==null?void 0:i.activeModelKeyDeductType),f=R(()=>i==null?void 0:i.activeModelKeyPrice),S=E(0),m=E(0),x=E(0),h=E(0),k=E(!1),w=E(null);ae(()=>s.userBalance.useModel3Token,($,T)=>{var N;S.value=T||0,m.value=$||0,(N=d.value)==null||N.play()},{immediate:!0,flush:"post"}),ae(()=>s.userBalance.useModel4Token,($,T)=>{var N;x.value=T||0,h.value=$||0,(N=u.value)==null||N.play()},{immediate:!0,flush:"post"});const{isMobile:C}=Ue(),p=E(!1),P=R(()=>n.siderCollapsed),v=E("");function _($){v.value=$,i.setGroupKeyWord($)}function L(){k.value=!1}function te(){r.push("/role")}async function y(){try{p.value=!0,await i.addNewChatGroup(),await i.queryMyGroup(),p.value=!1,C.value&&n.setSiderCollapsed(!0)}catch{p.value=!1}}async function z(){l.warning({title:"清空分组",content:"是否删除所有非置顶的对话组？",positiveText:"确认删除",negativeText:"再想想",onPositiveClick:async()=>{await i.delAllGroup()}})}function U(){n.setSiderCollapsed(!P.value)}function V(){k.value=!0,Ie(()=>{var $;($=w.value)==null||$.focus()})}const H=R(()=>C.value?{position:"fixed",zIndex:50}:{}),G=R(()=>C.value?{paddingBottom:"env(safe-area-inset-bottom)"}:{});return ae(C,$=>{n.setSiderCollapsed($)},{immediate:!0,flush:"post"}),($,T)=>(D(),F("div",null,[B(g(St),{collapsed:g(P),"collapsed-width":0,width:260,"show-trigger":g(C)?!1:"arrow-circle","collapse-mode":"transform",position:"absolute",bordered:"",style:xe(g(H)),onUpdateCollapsed:U},{default:J(()=>[O("div",{class:"flex flex-col h-full bg-[#fafbfc] dark:bg-[#18181c]",style:xe(g(G))},[O("main",wr,[k.value?(D(),F("div",Cr,[B(g(Q),{type:"primary",loading:p.value,onClick:y},{default:J(()=>[B(g(A),{icon:"ion:add-outline",class:"text-xl"})]),_:1},8,["loading"]),O("div",kr,[B(g(ze),{modelValue:v.value,"onUpdate:modelValue":T[0]||(T[0]=N=>v.value=N),ref_key:"searchRef",ref:w,type:"text",placeholder:"对话历史查找",onBlur:L,clearable:"",onInput:_},null,8,["modelValue"])])])):q("",!0),k.value?q("",!0):(D(),F("div",Rr,[O("div",Sr,[B(g(Q),{type:"primary",style:{width:"100%"},loading:p.value,onClick:y},{default:J(()=>[X(" 新对话 "),B(g(A),{icon:"ion:add-outline",class:"text-xl"})]),_:1},8,["loading"])]),B(g(Q),{onClick:V},{default:J(()=>[B(g(A),{icon:"icon-park-outline:search",class:"text-xl"})]),_:1})])),O("div",_r,[B(xr)]),g(C)?q("",!0):(D(),F("div",$r,[O("div",{class:"flex items-center w-full p-1 mb-1 text-[#3076fd] rounded cursor-pointer transition hover:bg-[#eef0f3] dark:border-neutral-700 dark:hover:bg-[#33373c]",onClick:T[1]||(T[1]=N=>g(o).updateGoodsDialog(!0))},[B(g(A),{icon:"material-symbols:shopping-bag-outline",class:"mr-1 text-base"}),X(" 进入市场选购您的商品 ")])])),O("div",Br,[g(a)===1?(D(),F("div",Tr,[B(g(A),{icon:"material-symbols:account-balance-wallet-outline",class:"ml-2 mr-2 text-base"}),X("普通额度： "+ee(`${g(c).sumModel3Count||0} 积分`),1)])):q("",!0),g(a)===1?(D(),F("div",Pr,[B(g(A),{icon:"ic:twotone-hourglass-top",class:"ml-2 mr-2 text-base"}),X(" 我已使用： "),B(g(we),{ref_key:"model3AnimationInstRef",ref:d,from:S.value,to:m.value},null,8,["from","to"]),X(" Token ")])):q("",!0),g(a)===1?(D(),F("div",Dr,[B(g(A),{icon:"mingcute:bill-line",class:"ml-2 mr-2 text-base"}),X(" 模型费用： "+ee(`${g(f)||0}积分 / 次对话`),1)])):q("",!0),g(a)===2?(D(),F("div",Lr,[B(g(A),{icon:"ic:twotone-hourglass-top",class:"ml-2 mr-2 text-base"}),X("我已使用： "),B(g(we),{ref_key:"model4AnimationInstRef",ref:u,from:x.value,to:h.value},null,8,["from","to"]),X(" Token ")])):q("",!0),g(a)===2?(D(),F("div",Ir,[B(g(A),{icon:"material-symbols:account-balance-wallet-outline",class:"ml-2 mr-2 text-base"}),X("高级额度： "+ee(`${g(c).sumModel4Count||0} 积分`),1)])):q("",!0),g(a)===2?(D(),F("div",zr,[B(g(A),{icon:"mingcute:bill-line",class:"ml-2 mr-2 text-base"}),X("模型费用： "+ee(`${g(f)||0}积分 / 次对话`),1)])):q("",!0),O("div",Ur,[B(g(Q),{type:"tertiary",size:"small",onClick:T[2]||(T[2]=N=>g(o).updateNoticeDialog(!0))},{default:J(()=>[B(g(A),{icon:"mdi:notice-board",class:"ml-2 mr-2 text-sm"}),Fr]),_:1}),B(g(Q),{type:"tertiary",size:"small",onClick:te},{default:J(()=>[B(g(A),{icon:"ri:emoji-sticker-line",class:"ml-2 mr-2 text-sm"}),Or]),_:1})]),O("div",Nr,[B(g(Q),{type:"tertiary",size:"small",style:{width:"100%"},onClick:z},{default:J(()=>[B(g(A),{icon:"ant-design:delete-outlined",class:"ml-2 mr-2 text-sm"}),jr]),_:1})])])])],4)]),_:1},8,["collapsed","show-trigger","style"]),g(C)?Ct((D(),F("div",{key:0,class:"fixed inset-0 z-40 bg-black/40",onClick:U},null,512)),[[kt,!g(P)]]):q("",!0)]))}});export{Gr as N,Hr as _};
