import{Y as o}from"./index-4223df14.js";const d={queryModels:e=>o.get("models/query",{params:e}),setModels:e=>o.post("models/setModel",e),delModels:e=>o.post("models/delModel",e)};export{d as A};
